# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: 05-raporty.spec.ts >> Raporty CSV w panelu webowym >> eksport stanu magazynowego pobiera plik CSV czytelny dla Excela
- Location: tests\05-raporty.spec.ts:6:3

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByText('Raporty CSV').or(getByLabel('Raporty CSV')).first()
Expected: visible
Timeout: 15000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" getByText('Raporty CSV').or(getByLabel('Raporty CSV')).first() with timeout 15000ms
  - waiting for getByText('Raporty CSV').or(getByLabel('Raporty CSV')).first()

```

```yaml
- button "Open navigation menu"
- heading "Panel główny" [level=2]
- group:
  - text: System magazynowy Szybki dostęp do najważniejszych funkcji magazynu.
  - button "Partie materiałów Podgląd partii i odpadów"
  - button "Lokalizacje Strefy, sektory i miejsca"
  - button "Skanowanie Skan etykiet i szybkie wyszukiwanie"
  - button "Przyjęcia Rejestr dostaw"
  - button "Wydania Historia wyjść z magazynu"
  - button "Raporty Analiza i zestawienia"
```

# Test source

```ts
  1  | import { expect, test } from '@playwright/test';
  2  | import fs from 'fs';
  3  | import { KONTA, kliknijTekst, przycisk, przyjmijPrzezApi, tekst, zalogujDoPanelu } from './pomocnicze';
  4  | 
  5  | test.describe('Raporty CSV w panelu webowym', () => {
  6  |   test('eksport stanu magazynowego pobiera plik CSV czytelny dla Excela', async ({ page, request }) => {
  7  |     const partia = await przyjmijPrzezApi(request, 'Rura stalowa', 'Półka S1-R3-P1', 8);
  8  | 
  9  |     await zalogujDoPanelu(page, KONTA.pracownik);
  10 |     await kliknijTekst(page, 'Raporty');
> 11 |     await expect(tekst(page, 'Raporty CSV')).toBeVisible();
     |                                              ^ Error: expect(locator).toBeVisible() failed
  12 | 
  13 |     const [pobieranie] = await Promise.all([
  14 |       page.waitForEvent('download'),
  15 |       przycisk(page, 'Eksportuj stan magazynowy').click(),
  16 |     ]);
  17 | 
  18 |     expect(pobieranie.suggestedFilename()).toBe('stan_magazynowy.csv');
  19 | 
  20 |     const plik = await pobieranie.path();
  21 |     const zawartosc = fs.readFileSync(plik);
  22 |     const wiersze = zawartosc.toString('utf8').trim().split(/\r?\n/);
  23 | 
  24 |     // Znacznik BOM, srednik jako separator i polskie znaki w naglowku.
  25 |     expect([...zawartosc.subarray(0, 3)]).toEqual([0xef, 0xbb, 0xbf]);
  26 |     expect(wiersze[0]).toContain('Kod partii');
  27 |     expect(wiersze[0]).toContain(';Materiał;');
  28 |     expect(wiersze.some((w) => w.startsWith(`${partia.batch_code};`))).toBe(true);
  29 |   });
  30 | 
  31 |   test('eksport historii ruchów pobiera plik CSV', async ({ page }) => {
  32 |     await zalogujDoPanelu(page, KONTA.kierownik);
  33 |     await kliknijTekst(page, 'Raporty');
  34 | 
  35 |     const [pobieranie] = await Promise.all([
  36 |       page.waitForEvent('download'),
  37 |       przycisk(page, 'Eksportuj historię ruchów').click(),
  38 |     ]);
  39 | 
  40 |     expect(pobieranie.suggestedFilename()).toBe('historia_ruchow.csv');
  41 |     const tresc = fs.readFileSync(await pobieranie.path(), 'utf8');
  42 |     expect(tresc.split(/\r?\n/)[0]).toContain(';');
  43 |   });
  44 | });
  45 | 
```